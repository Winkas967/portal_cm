package users.auth.dto;

import java.util.List;

public record MeResponse(
        String username,
        List<String> role,
        String displayRole
) {
}
