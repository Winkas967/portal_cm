package users.auth.dto;

public record AuthResponse(String token) {
}
